# Statistical Rigor Report (Two-Tailed Wilcoxon & Exact Sign Test)
Significance Thresholds: Nominal $\alpha = 0.05$, Bonferroni $\alpha_{\text{adj}} = 0.0167$ (m=3 families).

## Comparison: Hybrid-DDQN vs ALNS-Base (N=5 instances)
### 1. Fleet Size Reduction (NV):
- Mean NV: ALNS-Base = 14.00 vs Hybrid-DDQN = 13.60
- Record: 2 Wins / 3 Ties / 0 Losses
- Wilcoxon signed-rank: $W = 0.0$, $p = 5.0000e-01$ (Not Significant)
- Exact Sign test: $p = 5.0000e-01

### 2. Vehicle-Matched Distance Gap (TD):
- Matched Instances: 3/5 (60.0%)
- Mean TD Gap on Matched: -3.05%
- Record on Matched: 2 Wins / 1 Ties / 0 Losses
- Wilcoxon signed-rank: $W = 0.0$, $p = 5.0000e-01$ (Not Significant)
- Exact Sign test: $p = 5.0000e-01

---------------------------------------------------------------------------