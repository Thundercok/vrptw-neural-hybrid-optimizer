# Statistical Rigor Report (Two-Tailed Wilcoxon & Exact Sign Test)
Significance Thresholds: Nominal $\alpha = 0.05$, Bonferroni $\alpha_{\text{adj}} = 0.0167$ (m=3 families).

## Comparison: Hybrid-DDQN vs ALNS-Base (N=74 instances)
### 1. Fleet Size Reduction (NV):
- Mean NV: ALNS-Base = 9.94 vs Hybrid-DDQN = 9.68
- Record: 31 Wins / 40 Ties / 3 Losses
- Wilcoxon signed-rank: $W = 133.5$, $p = 6.9099e-07$ (Significant)
- Exact Sign test: $p = 7.6601e-07

### 2. Vehicle-Matched Distance Gap (TD):
- Matched Instances: 40/74 (54.1%)
- Mean TD Gap on Matched: -3.73%
- Record on Matched: 33 Wins / 7 Ties / 0 Losses
- Wilcoxon signed-rank: $W = 0.0$, $p = 9.3120e-08$ (Significant)
- Exact Sign test: $p = 2.3283e-10

---------------------------------------------------------------------------