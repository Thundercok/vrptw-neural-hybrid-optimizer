# Statistical Rigor Report (Two-Tailed Wilcoxon & Exact Sign Test)
Significance Thresholds: Nominal $\alpha = 0.05$, Bonferroni $\alpha_{\text{adj}} = 0.0167$ (m=3 families).
